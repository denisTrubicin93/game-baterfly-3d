import * as BABYLON from '@babylonjs/core';
import "@babylonjs/loaders"
import "@babylonjs/gui"
import { Flowers } from './Flowers'
import { gsap } from 'gsap'
import { startPosition, randomVector } from '../../../../utils/funcs'
import flowersModel from '../../assets/models/garden-bed3.glb'
import baterflyModel from '../../assets/models/buterfly.glb'

// import LoaderManager from "./LoaderManager";
import { MeshBuilder } from '@babylonjs/core';
import { randomVector } from 'utils/funcs';

export default class StudioSceneManager {
  constructor(game) {

    this.game = game;
    //Main Props
    this.scene = null;
    this.studioGui = null;
    this.mainCamera = null;

    this.catchBaterfly = null
    this.disableBaterfly = false
    this.currentBaterfly = 0
    this.baterflyActive = null
    this.baterflyList = []
    this.points = 0
    this.sound = null


    this.hla = null;
    this.hra = null;

  }

  //#region  MainSceneProperties
  CreateScene() {
    // let this_ = this
    //Create Bts Scene
    //Create Scene
    this.scene = new BABYLON.Scene(this.game.engine);
    this.scene.clearColor = new BABYLON.Color4(0, 0, 0, 0);
    this.scene.imageProcessingConfiguration.colorCurvesEnabled = true;
    this.scene.imageProcessingConfiguration.colorCurves = new BABYLON.ColorCurves();
    this.scene.imageProcessingConfiguration.colorCurves.globalSaturation = 0;
    this.scene.imageProcessingConfiguration.contrast = 2.5;
    this.scene.imageProcessingConfiguration.vignetteEnabled = true;

    this.createCamera();
    this.setUpEnvironMent();
    this.loadBaterflyModel()

    return this.scene;
  }
  createCamera() {
    this.camera = new BABYLON.ArcRotateCamera("Camera", 0, 0, 10, new BABYLON.Vector3(0, 0, 0), this.scene);
    this.camera.setPosition(new BABYLON.Vector3(0, 0, 1600));
    this.camera.upperBetaLimit = (Math.PI / 2) * 0.99;

    // const canvas = scene.getEngine().getRenderingCanvas();
    this.camera.attachControl(this.game.canvas, true)
    this.camera.fov = 0.1;
  }
  async setUpEnvironMent() {
    let hemiLight = new BABYLON.HemisphericLight(
      "HemiLight",
      new BABYLON.Vector3(0, 100, -0),
      this.scene
    );
    hemiLight.intensity = 1.5;

    // var blueMat = new BABYLON.StandardMaterial("ground", this.scene);
    // blueMat.diffuseColor = new BABYLON.Color3(0.4, 0.4, 0.4);
    // blueMat.specularColor = new BABYLON.Color3(0.4, 0.4, 0.4);
    // blueMat.emissiveColor = BABYLON.Color3.Blue()
    var groundMaterial = new BABYLON.StandardMaterial("ground", this.scene);
    groundMaterial.specularColor = new BABYLON.Color3(0, 0, 0);
    groundMaterial.alpha = 0
    this.ground = BABYLON.MeshBuilder.CreateGround("ground", { width: 100, height: 200 }, this.scene);
    this.ground.rotation.x = Math.PI / 2
    // this.ground.position.z = -20
    this.ground.material = groundMaterial;
    // let sphere = BABYLON.MeshBuilder.CreateSphere('sphere', { diameter: 5 }, this.scene)
    // sphere.position = new BABYLON.Vector3(-15, -67, 20)
    const flowers = await BABYLON.SceneLoader.ImportMeshAsync(
      "",
      flowersModel,
      "",
      this.scene,
      undefined,
    );
    // flowers.meshes[0].scaling = new BABYLON.Vector3(8, 8, 8)
    flowers.meshes[0].position = new BABYLON.Vector3(0, -65, -1)
    // console.log(flowers)
  }

  moveBaterfly() {
    if (this.catchBaterfly) return
    let randomPos = randomVector()
    gsap.to(this.baterflyActive.meshes[0].position, 4, {
      x: randomPos.x, y: randomPos.y, onComplete: () => {
        if (!this.catchBaterfly)
          this.moveBaterfly()
      }
    })
  }

  async loadBaterflyModel() {

    let baterfly = await BABYLON.SceneLoader.ImportMeshAsync(
      "",
      baterflyModel,
      '',
      this.scene,
      undefined,
    );
    baterfly.meshes[0].name = `baterfly${this.currentBaterfly}`
    // baterfly.meshes[0].scaling = new BABYLON.Vector3(-8, -8, -8)
    // baterfly.meshes[0].position.z = 20
    baterfly.meshes[0].rotation.x = Math.PI / 4
    baterfly.meshes[0].rotation.y = Math.PI / 1.3
    baterfly.meshes[0].rotationQuaternion = undefined
    baterfly.meshes[1].isVisible = false
    // let newBaterfly = this.baterfly.clone('baterfly1')
    this.baterflyList.push(baterfly)
    this.baterflyActive = this.baterflyList[this.currentBaterfly]
    // console.log(this.baterflyActive)
    this.initPosBaterfly = startPosition()
    this.baterflyActive.meshes[0].position = new BABYLON.Vector3(this.initPosBaterfly.x, this.initPosBaterfly.y, 20)
    setTimeout(() => {
      this.moveBaterfly()
    }, 1000);
  }

  getGroundPosition(handCoord) {
    let pickinfo = this.scene.pick(handCoord.xMin, handCoord.yMin, (mesh) => true);
    // console.log(scene.pointerX)
    if (pickinfo.hit) {
      return pickinfo.pickedPoint;
    }
    return null;
  }

  detectBaterfly(posBaterfly, hand) {
    if (this.startingPoint.x < posBaterfly.x + 10 &&
      this.startingPoint.x > posBaterfly.x - 10 &&
      this.startingPoint.y < posBaterfly.y + 10 &&
      this.startingPoint.y > posBaterfly.y - 10) {
      this.sound = 'catch'
      this.catchBaterfly = hand
    }
  }

  detectFlowers(posBaterfly, flower) {
    // console.log('posBaterfly', posBaterfly.x, flower)
    if (posBaterfly.x < flower.xMax &&
      posBaterfly.x > flower.xMin &&
      posBaterfly.y < flower.yMax &&
      posBaterfly.y > flower.yMin) {
      posBaterfly.x = flower.xMin + 5
      posBaterfly.y = -25
      // console.log('touchFlower')
      // this.touchFlower = flower.id
      let parentNode = this.scene.getMeshByName(`anchor${flower.id}-${flower.currentAnchor}`)
      this.baterflyActive.meshes[0].rotation = new BABYLON.Vector3(0, Math.PI, 0)
      this.baterflyActive.meshes[0].position = new BABYLON.Vector3(0, 0, 0)
      this.baterflyActive.meshes[0].parent = parentNode
      this.baterflyActive.meshes[0].name = 'disable'
      this.catchBaterfly = null
      if (flower.currentAnchor < flower.maxAnchor)
        flower.currentAnchor++
      else
        flower.isActive = true
      this.currentBaterfly++
      this.points++
      this.sound = 'success'
      this.loadBaterflyModel()

      // this.baterflyActive = null
      // this.baterflyActive = this.baterfly.clone('baterfly2')
      // console.log(this.baterflyActive)

      // this.disableBaterfly = true
    }
  }

  pointerDown(model, handCoord, hand) {
    let this_ = this
    // currentMesh = mesh;
    let canvasCoord = this.getGroundPosition(handCoord)
    if (!canvasCoord) return
    this.startingPoint = {
      x: canvasCoord.x,
      y: canvasCoord.y
    };
    // if (hand === 'left')
    //   console.log('111111111111111111', this.startingPoint)

    this.baterflyActive.meshes[1].isVisible = true

    let posBaterfly = this.baterflyActive.meshes[0].position

    if (posBaterfly && this.baterflyActive.meshes[0].name !== 'disable') {
      // console.log(this.scene)
      // // this.baterflyActive.meshes[0].scaling = new BABYLON.Vector3(-1, -1, -1)

      // // this.baterflyActive.meshes[0].rotation.y = Math.PI
      // this.baterflyActive.meshes[0].position = parentNode.getAbsolutePosition()
      // console.log(parentMesh)
      // this.baterflyActive.transformNodes[12].position.x = -10

      if (this.catchBaterfly === hand) {
        gsap.to(model.meshes[0].position, 0.5, { x: this.startingPoint.x, y: this.startingPoint.y })
        // model.meshes[0].position.x = this.startingPoint.x
        // model.meshes[0].position.y = this.startingPoint.y
        for (let i = 0; i < Flowers.length; i++) {
          if (!Flowers[i].isActive)
            this.detectFlowers(posBaterfly, Flowers[i])
        }
      } else {
        this.detectBaterfly(posBaterfly, hand)
      }
    }

    // console.log('Detect', this.startingPoint.y)

    // if (startingPoint.x >= blueBox.position.x - 20 && startingPoint.x <= blueBox.position.x + 20)
    //     console.log(startingPoint, blueBox)
    if (this.startingPoint) { // we need to disconnect camera from canvas
      setTimeout(() => {
        this_.camera.detachControl(this_.game.canvas);
      }, 0);
    }
  }

  handlePoints(onCheckpoints) {
    onCheckpoints(this.points)
  }
  handleSound(onCheckSound) {
    onCheckSound(this.sound)
    this.sound = null
  }

  handlerCoord(hla, hra) {
    this.hla = hla;
    this.hra = hra;
    if (this.baterflyActive) {
      this.pointerDown(this.baterflyActive, this.hla, 'left')
      this.pointerDown(this.baterflyActive, this.hra, 'right')
    }

  }

}

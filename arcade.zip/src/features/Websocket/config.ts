export const wsServer = process.env.WEBSOCKET_SERVER || 'ws://localhost:5500';

interface DeviceState {
  camera: 'occupied' | 'not-occupied' | undefined;
}

export { DeviceState };
